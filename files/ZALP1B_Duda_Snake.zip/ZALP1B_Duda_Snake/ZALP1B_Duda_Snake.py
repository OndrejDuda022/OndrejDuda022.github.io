#IMPORT KNIHOVEN
import pygame
import math
import random
import easygui

#BARVY
white = (255, 255, 255)
black = (0, 0, 0)
red = (255, 0, 0)
yellow = (255, 255, 0)
green = (0, 128, 0)
skin = (232, 190, 172)
grass = (203, 240, 98)
random_rgb = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))

#NASTAVENÍ PYGAME OKNA
pygame.init()
pygame.display.set_caption('Načítání...')
dis_width = 800
dis_height = 800
dis = pygame.display.set_mode((dis_width, dis_height))

#DATA
apple_eaten = pygame.mixer.Sound('sound/apple_eaten.wav')
apple_eaten.set_volume(0.3)

pear_eaten = pygame.mixer.Sound('sound/pear_eaten.wav')
pear_eaten.set_volume(0.3)

golden_apple_eaten = pygame.mixer.Sound('sound/secret_apple_eaten.wav')
golden_apple_eaten.set_volume(0.3)

golden_pear_eaten = pygame.mixer.Sound('sound/secret_pear_eaten.wav')
golden_pear_eaten.set_volume(0.3)

golden_pear_spawn = pygame.mixer.Sound('sound/secret_pear_appear.wav')
golden_pear_spawn.set_volume(0.1)

snake_hit = pygame.mixer.Sound('sound/snake_hit.wav')
snake_hit.set_volume(0.3)

apple_img = pygame.image.load('images/apple.png')
img_width, img_height = apple_img.get_size()
apple_img = pygame.transform.scale(apple_img, ((img_width/100)*15, (img_height/100)*15))

golden_apple_img = pygame.image.load('images/secret_apple.png')
img_width, img_height = golden_apple_img.get_size()
golden_apple_img = pygame.transform.scale(golden_apple_img, ((img_width/100)*15, (img_height/100)*15))

pear_img = pygame.image.load('images/pear.png')
pear_img_width, pear_img_height = pear_img.get_size()
pear_img = pygame.transform.scale(pear_img, ((pear_img_width/100)*10, (pear_img_height/100)*10))

golden_pear_img = pygame.image.load('images/secret_pear.png')
pear_img_width, pear_img_height = golden_pear_img.get_size()
golden_pear_img = pygame.transform.scale(golden_pear_img, ((pear_img_width/100)*10, (pear_img_height/100)*10))

secret_head_img = pygame.image.load('images/secret_head.png')
head_img_width, head_img_height = secret_head_img.get_size()
secret_head_img = pygame.transform.scale(secret_head_img, ((head_img_width/100)*25, (head_img_height/100)*25))

background_img = pygame.image.load('images/background.jpg')

#STYL
font_size = 50
font_style = pygame.font.SysFont("arialblack", font_size)

#DEFINOVÁNÍ FUNKCÍ
def gameloop():

    #ZÁKLADNÍ PROMĚNNÉ
    game_over = False
    practice_mode = False
    hard_mode = False
    rare_shift = ""
    random_shift = ""
    pear_chance = ""
    gold_chance = ""
    gold_appear_played = False
    not_speed_warned = True
    loop_speed = pygame.time.Clock()
    snake_list = []
    snake_len = 1

    #NASTAVENÍ POZADÍ
    grass_mode = False

    #NASTAVENÍ HADA
    snake_piece = 25
    speed = 200
    color = green
    speed_multiplier = 2
    top_speed = 1000

    #NASTAVENÍ JÍDLA
    food_size = 20
    snake_positions = set(snake_list)
    while True:
        food_x = random.randint(food_size + (dis_width/100)*5, dis_width - (food_size + (dis_width/100)*5))
        food_y = random.randint(food_size + (dis_height/100)*5, dis_height - (food_size + (dis_height/100)*5))
    
        #kontrola kolize
        collision = False
        for pos in snake_positions:
            if (food_x >= pos[0] - snake_piece*2 and food_x <= pos[0] + snake_piece*2) and (food_y >= pos[1] - snake_piece*2 and food_y <= pos[1] + snake_piece*2):
                collision = True
                break
        if not collision:
            break
 
    #POČÁTČNÍ SOUŘADNICE
    snake_x = dis_width/2 - snake_piece/2
    snake_y = dis_height/2 - snake_piece/2
 
    snake_x_update = 0       
    snake_y_update = 0

    #HERNÍ SMYČKA

    #definování skóre
    global score
    score = 0
    global rare_score
    rare_score = 0

    #zadání jména
    nick = ""
    while not nick:
        nick = easygui.enterbox("Zadej jméno:", title="Herní nick")
        if not nick:
            easygui.msgbox("Musíte zadat alespoň 1 znak.", title="Neplatné jméno!", ok_button="Chápu")
        else:
            if nick == "Easy" or nick == "Cvičení" or nick == "Practice":
                practice_mode = True
                mode_snake_multiplier = -2
                print("Cvičný mód aktivován!")
            elif nick == "Hard" or nick == "Výzva" or nick == "Challenge":
                hard_mode = True
                mode_snake_multiplier = 5
                print("Obtížný mód aktivován!")
            else:
                mode_snake_multiplier = 0
            break
            
    #smyčka
    while game_over == False:
    
        #zobrazení skóre v názvu okna
        if practice_mode == True:
            if rare_shift == 0:
                pygame.display.set_caption('Duda Ondřej P1B od Had | Cvičný mód | Skóre: ' + str(score))
            else:
                pygame.display.set_caption('Had od Duda Ondřej P1B | Cvičný mód | Skóre: ' + str(score))
        elif hard_mode == True:
            if rare_shift == 0:
                pygame.display.set_caption('Duda Ondřej P1B od Had | Výzva | Skóre: ' + str(score))
            else:
                pygame.display.set_caption('Had od Duda Ondřej P1B | Výzva | Skóre: ' + str(score))
        else:
            if rare_shift == 0:
                pygame.display.set_caption('Duda Ondřej P1B od Had | Skóre: ' + str(score))
            else:
                pygame.display.set_caption('Had od Duda Ondřej P1B | Skóre: ' + str(score))

        #selektor jídla
        if gold_chance == 0 and pear_chance == 0:
            render_food = golden_pear_img
            if gold_appear_played == False:
                gold_appear_played = True
                golden_pear_spawn.play()
        elif gold_chance == 0:
            render_food = golden_apple_img
        elif pear_chance == 0:
            render_food = pear_img
        else:
            render_food = apple_img
    
        #vstup uživatele
        for event in pygame.event.get():
        
            #vypínač 1
            if event.type == pygame.QUIT:
                game_over = True
            
            #stisk klávesy
            if event.type == pygame.KEYDOWN:
            
                #směr pohybu
                if event.key == pygame.K_a or event.key == pygame.K_LEFT:
                    snake_x_update = -1
                    snake_y_update = 0
                elif event.key == pygame.K_d or event.key == pygame.K_RIGHT:
                    snake_x_update = 1
                    snake_y_update = 0
                elif event.key == pygame.K_w or event.key == pygame.K_UP:
                    snake_y_update = -1
                    snake_x_update = 0
                elif event.key == pygame.K_s or event.key == pygame.K_DOWN:
                    snake_y_update = 1
                    snake_x_update = 0

                #easter egg
                elif event.key == pygame.K_r:
                    rare_shift = random.randint(0,9)
                    random_rgb = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
                    color = random_rgb
                
                #vypínač 2
                elif event.key == pygame.K_ESCAPE:
                    game_over = True

        #kontrola hranic
        if snake_x + snake_piece >= dis_width or snake_x - snake_piece < 0 or snake_y + snake_piece >= dis_height or snake_y - snake_piece < 0:
            game_over = True

        #kontrola kolize hlavy a těla
        if any((snake_x == list_x and snake_y == list_y ) for list_x, list_y in snake_list[:-snake_piece]):
        #if any(math.sqrt((snake_x - list_x)**2 + (snake_y - list_y)**2) < ((snake_piece/100)*90 + snake_piece/2) for list_x, list_y in snake_list[:-snake_piece*2]):
        #if any(snake_head.colliderect(pygame.Rect(x, y, snake_piece, snake_piece)) for x, y in snake_list[:-snake_piece*5]):
            game_over = True

        #pohyb
        snake_x += snake_x_update
        snake_y += snake_y_update
        snake_list.append((snake_x, snake_y))
        if len(snake_list) > snake_len * snake_piece:
            del snake_list[0]

        if grass_mode == True:
            dis.blit(background_img, (0, 0))
        else:
            dis.fill(grass)

        #vykreslení jídla
        food_hitbox = pygame.draw.circle(dis, grass, (food_x, food_y), food_size)
        dis.blit(render_food, (food_x - food_size, food_y - 1.5 * food_size))

        #vykreslení hada
        if rare_shift == 0:
            color = skin

        for i, (x, y) in enumerate(snake_list):
            if i % snake_piece == 0:
                pygame.draw.circle(dis, color, (x, y), (snake_piece/100)*90)

        if rare_shift == 0:
            snake_head = pygame.draw.circle(dis, skin, (snake_x, snake_y), snake_piece)
            snake_texture = dis.blit(secret_head_img, (snake_x - food_size, snake_y - 1.5 * food_size))
        else:
            snake_head = pygame.draw.circle(dis, tuple(c * 0.7 for c in color), (snake_x, snake_y), snake_piece) 

        #ukazatel skóre v levém horním rohu
        score_display = font_style.render(str(score), True, black)
        dis.blit(score_display, [(dis_width/100)*10, (dis_height/100)*10])
        pygame.display.update()

        #kontrola kolize s jídlem    
        if snake_head.colliderect(food_hitbox):
            if gold_chance == 0 and pear_chance == 0:
                print("Jaká je šance?!")
                pygame.mixer.stop()
                golden_pear_eaten.play()
                score += 1000
                rare_score += 10
                speed += (speed/100)*(speed_multiplier*10)
                snake_len += 10
                gold_appear_played = False

            elif pear_chance == 0:
                pear_eaten.play()
                score += 10
                speed += (speed/100)*(speed_multiplier*5)
                snake_len += 5
            
            elif gold_chance == 0:
                print("Opravdová delikatesa!")
                golden_apple_eaten.play()
                score += 100
                rare_score += 1
                speed += (speed/100)*(speed_multiplier*10)
                snake_len += 10

            else:
                apple_eaten.play()
                score += 1
                speed += (speed/100)*speed_multiplier
                snake_len += 2 + mode_snake_multiplier
            
            print(score)
            random_shift = random.randint(0,9)

            #vytvoření nového jídla
            while True:
                food_x = random.randint(food_size + (dis_width/100)*5, dis_width - (food_size + (dis_width/100)*5))
                food_y = random.randint(food_size + (dis_height/100)*5, dis_height - (food_size + (dis_height/100)*5))
    
                #kontrola kolize
                collision = False
                for pos in snake_positions:
                    if (food_x >= pos[0] - snake_piece*2 and food_x <= pos[0] + snake_piece*2) and (food_y >= pos[1] - snake_piece*2 and food_y <= pos[1] + snake_piece*2):
                        collision = True
                        break
                if not collision:
                    break
            if practice_mode == True:
                pear_chance = random.randint(0, 4)
                gold_chance = random.randint(0, 19)
            elif hard_mode == True:
                pear_chance = random.randint(0, 39)
                gold_chance = random.randint(0, 199)
            else:
                pear_chance = random.randint(0, 19)
                gold_chance = random.randint(0, 99)
            #print(snake_list)
        else:
            pass

        #závěr smyčky
        snake_positions = set(snake_list)
        if random_shift == 0:
            random_rgb = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
            color = random_rgb
            random_shift = 1

        if speed >= top_speed:
            speed = top_speed
            if not_speed_warned == True:
                not_speed_warned = False
                print("Maximální rychlost dosažena!")

        if practice_mode == True:
            loop_speed.tick(speed/2)
        elif hard_mode == True:
            loop_speed.tick(speed*2)
        else:
            loop_speed.tick(speed)
            
    #KONEC
    #dis.blit(background_img, (0, 0))
    pygame.mixer.stop()
    snake_hit.play()
    dis.fill(grass)
    notification("Game Over",red)
    pygame.display.set_caption('Game Over! Vaše skóre bylo uloženo. ESC pro ukončení! R pro Znovu!')
    pygame.display.update()

    #ULOŽENÍ SKÓRE
    with open("score.txt", "a") as file:
        if rare_score != 0:
            file.write('\n' + str(nick) + ': ' + str(score) + ' | Gratuluji, snědli jste ' + str(rare_score) + ' Zlatého ovoce!' + '\n')
        else:
            file.write('\n' + str(nick) + ': ' + str(score) + '\n')
        file.close()

def notification(msg, color):
    display = font_style.render(msg, True, color)
    display_middle = display.get_rect()
    display_middle.center = (dis_width/2, dis_height/2)
    dis.blit(display, display_middle)                                

#SPUŠTĚNÍ HRY
gameloop()

#UKONČENÍ ČI OPAKOVÁNÍ HRY
game_close = False
while game_close == False:
    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                game_close = True
            elif event.key == pygame.K_r:
                print("RESTART")
                gameloop()
        elif event.type == pygame.QUIT:
            game_close = True
        
pygame.quit()
quit()
